@echo off
echo Starting Smart Retail Hub...
echo.
python -m http.server 8000
pause
