# 🎯 VS Code में Project कैसे चलाएं

## 📋 Files Ready हैं:

```
smart-retail-hub-complete/
├── 📄 index.html              ← Home page
├── 📄 login.html              ← Login page (शुरुआत यहाँ से करो!)
├── 📄 dashboard.html          ← Main dashboard
├── 📄 firebase-config.js      ← Firebase configuration
│
├── 📁 pages/                  ← Feature pages
│   ├── products.html
│   ├── customers.html
│   ├── billing.html
│   ├── inventory.html
│   ├── reports.html
│   └── settings.html
│
├── 📁 assets/
│   ├── css/
│   │   └── style.css          ← सभी styling
│   └── js/
│       ├── login.js
│       ├── dashboard.js
│       ├── products.js
│       ├── customers.js
│       ├── billing.js
│       ├── inventory.js
│       ├── reports.js
│       └── settings.js
│
├── 📁 components/             ← भविष्य के लिए (अभी खाली)
├── 📁 docs/                   ← Documentation
│   ├── README.md
│   ├── SETUP.md
│   └── QUICKSTART.md
│
└── 📄 HOW_TO_USE_IN_VSCODE.md ← ये file
```

---

## 🚀 VS Code में खोलने के Steps:

### Step 1: VS Code खोलो
```
1. VS Code खोलो
2. File → Open Folder
3. "smart-retail-hub-complete" folder select करो
4. Open दबाओ
```

### Step 2: Extensions Install करो (Optional पर Recommended)
```
VS Code में:
1. Ctrl + Shift + X (Extensions)
2. Search करो: "Live Server"
3. Install करो (Ritwick Dey वाला)
4. Same तरीके से install करो:
   - "Prettier" (Code formatting)
   - "Thunder Client" (API testing)
   - "GitLens" (Code history)
```

### Step 3: Live Server चलाओ
```
तरीका 1 (सबसे आसान):
  1. login.html पर right-click करो
  2. "Open with Live Server" दबाओ
  3. Browser automatically खुल जाएगा
  4. http://127.0.0.1:5500 दिखेगा

तरीका 2 (अगर तरीका 1 काम न करे):
  1. VS Code में Terminal खोलो (Ctrl + `)
  2. ये command लिखो:
     python -m http.server 8000
  3. Browser खोलो: http://localhost:8000
```

---

## 🎬 कैसे काम करता है?

### File Structure समझो:

```
जब तुम login.html खोलते हो:
  ↓
HTML Browser को बताता है क्या दिखाना है
  ↓
assets/css/style.css से styling आती है
  ↓
assets/js/login.js से Logic आती है
  ↓
firebase-config.js से Firebase setup आती है
  ↓
💥 Beautiful UI दिखता है!
```

---

## 🎯 सबसे पहले ये करो:

### 1. Project को Terminal में खोलो
```bash
# VS Code में Terminal खोलो (Ctrl + `)
# फिर ये command दो:

python -m http.server 8000
```

### 2. Browser में खोलो
```
http://localhost:8000
```

### 3. सभी Pages देखो
```
- index.html (Home)
- login.html (Login)
- dashboard.html (Dashboard)
- pages/products.html
- pages/customers.html
- pages/billing.html
- pages/inventory.html
- pages/reports.html
- pages/settings.html
```

---

## 🔧 Useful VS Code Shortcuts:

| Shortcut | क्या करता है |
|----------|-----------|
| `Ctrl + ~` | Terminal खोलो/बंद करो |
| `Ctrl + /` | Comment/Uncomment |
| `Ctrl + S` | Save करो |
| `Ctrl + F` | Search करो |
| `Ctrl + H` | Find & Replace |
| `Ctrl + Shift + P` | Command Palette |
| `Alt + Shift + Down` | Line copy करो |
| `Ctrl + K Ctrl + 0` | Fold सभी |
| `F12` | Browser DevTools |

---

## 📝 Files को Edit करने के लिए:

### HTML Edit करना:
```
1. कोई भी .html file खोलो
2. F12 दबाकर देखो बदलाव
3. Live Server auto-refresh करेगा
```

### CSS Edit करना:
```
1. assets/css/style.css खोलो
2. CSS variable बदलो:
   --primary-color: #3b82f6  ← Color
   --dark-color: #0f172a    ← Background
3. File save करो → Auto reload हो जाएगा
```

### JavaScript Edit करना:
```
1. assets/js/ में file खोलो
2. Code बदलो
3. Browser refresh करो (F5)
4. Changes देख सकते हो
```

---

## 🎨 CSS Colors बदलना:

### style.css के top में ये हैं:

```css
:root {
    --primary-color: #3b82f6;      ← नीला
    --secondary-color: #0ea5e9;    ← Light नीला
    --success-color: #10b981;      ← हरा
    --warning-color: #f59e0b;      ← नारंगी
    --danger-color: #ef4444;       ← लाल
}
```

इन्हें बदलकर अपना color scheme बनाओ!

---

## 🔐 Firebase Setup के लिए:

### 1. firebase-config.js खोलो
```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",           ← बदलो
  authDomain: "YOUR_PROJECT.firebaseapp.com",  ← बदलो
  projectId: "YOUR_PROJECT_ID",     ← बदलो
  storageBucket: "YOUR_BUCKET.appspot.com",    ← बदलो
  messagingSenderId: "YOUR_ID",     ← बदलो
  appId: "YOUR_APP_ID"              ← बदलो
};
```

### 2. Firebase से credentials लो
```
1. firebase.google.com जाओ
2. Project create करो
3. Web app register करो
4. Config copy करो
5. firebase-config.js में paste करो
```

---

## ✨ Tips & Tricks:

### 1. Code Formatting
```
Ctrl + Shift + P → Format Document
यह automatically code को format कर देगा
```

### 2. Multi-line Edit
```
Ctrl + Click करो multiple जगहों पर
फिर type करो सब जगह change हो जाएगा
```

### 3. Quick Preview
```
Ctrl + K → V दबाओ
HTML का live preview देख सकते हो
```

### 4. Terminal में Fast Server
```bash
# सबसे fast:
npx http-server

# या Python:
python -m http.server 8000

# या VS Code Live Server (सबसे easy)
Right-click → Open with Live Server
```

---

## 🐛 Problem Solving:

### Problem: Page load नहीं हो रहा
**Solution:**
```
1. Terminal में clear करो (Ctrl + L)
2. Command फिर से दो
3. Browser cache clear करो (Ctrl + Shift + Del)
4. Page refresh करो (Ctrl + R)
```

### Problem: Styling नहीं आ रही
**Solution:**
```
1. F12 खोलो (DevTools)
2. Console tab देखो
3. Errors check करो
4. CSS file path सही है कि नहीं check करो
```

### Problem: JavaScript काम नहीं कर रही
**Solution:**
```
1. F12 खोलो
2. Console में errors देखो
3. assets/js/ files की path सही है कि नहीं
4. Firebase config सही है कि नहीं
```

---

## 📱 Mobile Testing:

### Browser DevTools में:
```
1. F12 दबाओ
2. Ctrl + Shift + M दबाओ
3. Device select करो (iPhone/Android)
4. Mobile view में देख सकते हो
```

---

## 🎯 Next Steps:

```
1. ✅ Project को VS Code में खोलो
2. ✅ Live Server से चलाओ
3. ✅ सभी pages explore करो
4. ✅ Dark mode test करो
5. ✅ Mobile view में देखो
6. ✅ Code को समझो
7. ✅ Firebase setup करो (docs/SETUP.md देखो)
8. ✅ Deploy करो Firebase Hosting में
```

---

## 🎉 Ready!

**अब बस ये करो:**

```
1. VS Code खोलो
2. smart-retail-hub-complete folder खोलो
3. login.html पर right-click → Open with Live Server
4. 🚀 Boom! Project चल गया!
```

---

## 📞 Quick Reference:

| काम | कैसे करें |
|-----|---------|
| **Project खोलो** | File → Open Folder |
| **Server चलाओ** | Right-click on HTML → Open with Live Server |
| **Terminal खोलो** | Ctrl + ` |
| **Browser Refresh** | F5 या Ctrl + R |
| **DevTools** | F12 |
| **Search** | Ctrl + F |
| **Find & Replace** | Ctrl + H |
| **Extensions** | Ctrl + Shift + X |
| **Command Palette** | Ctrl + Shift + P |

---

**Happy Coding! 🚀**

अगर कोई issue हो तो:
1. docs/SETUP.md पढ़ो
2. Browser console (F12) देखो
3. Terminal में errors देखो
4. Code comments पढ़ो - सब explain है!
