# Smart Retail Hub - Digital Shop Management System

A modern, Firebase-based retail management system designed for small shops and grocery stores. This is a professional Final Year BCA project that provides a complete solution for digital shop management.

## Project Overview

Smart Retail Hub is a comprehensive web-based application that helps local shopkeepers digitally manage their business operations including products, inventory, customers, billing, and sales reports with a beautiful, responsive dashboard.

## Features

### Core Features
- **Dashboard Analytics** - Real-time sales overview with interactive charts
- **Product Management** - Add, edit, delete products with image upload
- **Customer Management** - Maintain customer database with purchase history
- **Billing System** - Generate professional invoices with QR codes
- **Inventory Management** - Real-time stock tracking with low stock alerts
- **Sales Reports** - Comprehensive analytics and revenue tracking
- **Dark/Light Mode** - User-friendly theme toggle

### Advanced Features
- 🔐 Firebase Authentication (Email/Password)
- 📊 Chart.js Analytics Visualization
- 📄 PDF Invoice Generation
- 🔲 QR Code Invoice Verification
- 📱 Fully Responsive Design
- 🌙 Dark Mode Toggle
- 💾 Offline Data Persistence
- 🔔 Low Stock Notifications
- 📈 Sales & Revenue Analytics

## Technology Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with CSS Grid & Flexbox
- **Bootstrap 5** - Responsive UI components
- **JavaScript (ES6+)** - Modern JavaScript with modules

### Backend & Database
- **Firebase Authentication** - Secure user authentication
- **Firebase Firestore** - NoSQL cloud database
- **Firebase Storage** - Image storage for products
- **Firebase Hosting** - Production deployment

### Libraries & Tools
- **Chart.js** - Interactive charts and graphs
- **QRCode.js** - QR code generation
- **html2pdf.js** - PDF invoice generation
- **Bootstrap Icons** - Font Awesome icons

## Project Structure

```
smart-retail-hub/
│
├── index.html                  # Main entry page
├── login.html                  # Login & authentication page
├── dashboard.html              # Main dashboard
├── firebase-config.js          # Firebase configuration
│
├── assets/
│   ├── css/
│   │   └── style.css          # Main stylesheet
│   ├── js/
│   │   ├── login.js           # Login functionality
│   │   ├── dashboard.js       # Dashboard logic
│   │   ├── products.js        # Products management
│   │   ├── customers.js       # Customers management
│   │   ├── billing.js         # Billing system
│   │   ├── inventory.js       # Inventory tracking
│   │   ├── reports.js         # Reports & analytics
│   │   └── settings.js        # User settings
│   └── images/
│       └── (product images)
│
├── pages/
│   ├── products.html          # Products page
│   ├── customers.html         # Customers page
│   ├── billing.html           # Billing/Invoice page
│   ├── inventory.html         # Inventory page
│   ├── reports.html           # Reports page
│   └── settings.html          # Settings page
│
├── components/
│   ├── sidebar.html           # Sidebar component
│   ├── navbar.html            # Top navbar
│   └── footer.html            # Footer component
│
└── documentation/
    ├── README.md              # This file
    ├── SETUP.md               # Setup instructions
    ├── DATABASE_SCHEMA.md     # Database structure
    ├── API_DOCUMENTATION.md   # API reference
    ├── VIVA_QUESTIONS.md      # Viva Q&A
    └── DEPLOYMENT.md          # Deployment guide
```

## Firestore Database Schema

### Collections Structure

#### Users Collection
```javascript
{
  uid: "user_id",
  name: "Shop Owner Name",
  email: "owner@example.com",
  shopName: "Shop Name",
  phone: "1234567890",
  address: "Shop Address",
  city: "City Name",
  state: "State Name",
  role: "owner",
  createdAt: Timestamp,
  updatedAt: Timestamp
}
```

#### Products Collection
```javascript
{
  uid: "user_id",
  productName: "Product Name",
  category: "Category",
  price: 100.00,
  quantity: 50,
  imageURL: "https://...",
  createdAt: Timestamp,
  updatedAt: Timestamp
}
```

#### Customers Collection
```javascript
{
  uid: "user_id",
  customerName: "Customer Name",
  phone: "9876543210",
  address: "Customer Address",
  totalPurchases: 5000.00,
  purchaseCount: 10,
  createdAt: Timestamp,
  lastPurchaseDate: Timestamp
}
```

#### Bills Collection
```javascript
{
  uid: "user_id",
  customerName: "Customer Name",
  products: [
    {
      name: "Product Name",
      quantity: 2,
      price: 100,
      total: 200
    }
  ],
  subtotal: 200.00,
  gst: 36.00,
  totalAmount: 236.00,
  gstPercent: 18,
  paymentMethod: "cash",
  createdAt: Timestamp
}
```

## Setup Instructions

### Prerequisites
- Node.js (for local development)
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Firebase Project

### 1. Firebase Setup

1. Create a Firebase project at [firebase.google.com](https://firebase.google.com)
2. Enable Authentication (Email/Password)
3. Create Firestore Database (Start in test mode)
4. Enable Storage
5. Copy your Firebase config

### 2. Configure Firebase

Update `firebase-config.js` with your Firebase credentials:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

### 3. Firestore Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth.uid != null;
      
      // Ensure users can only read/write their own data
      match /products/{document=**} {
        allow read, write: if request.auth.uid == resource.data.uid;
        allow create: if request.auth.uid == request.resource.data.uid;
      }
      
      match /bills/{document=**} {
        allow read, write: if request.auth.uid == resource.data.uid;
        allow create: if request.auth.uid == request.resource.data.uid;
      }
    }
  }
}
```

### 4. Storage Rules

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /products/{userId}/{allPaths=**} {
      allow read, write: if request.auth.uid == userId;
    }
  }
}
```

### 5. Local Development

1. Clone or download the project
2. Open `login.html` in your browser
3. Create an account or login
4. Start managing your shop!

## Usage Guide

### Creating an Account
1. Click "Sign Up" on login page
2. Enter Shop Name, Email, and Password
3. Confirm password and create account
4. Login with your credentials

### Adding Products
1. Go to Products page
2. Click "Add New Product"
3. Fill in product details
4. Upload product image (optional)
5. Click "Save Product"

### Creating Invoices
1. Go to Billing page
2. Enter customer name
3. Select products and quantities
4. Adjust GST if needed
5. Click "Generate Invoice"
6. Print or Download as PDF

### Viewing Reports
1. Go to Reports page
2. Select date range
3. View sales charts and analytics
4. Export data if needed

## Key Features Explained

### Dark Mode
- Toggle between light and dark themes
- Settings saved in localStorage
- Applies to entire application

### Invoice QR Code
- Automatic QR code generation
- Contains invoice ID and amount
- Print-friendly format

### Low Stock Alerts
- Automatic notification for items below 10 units
- Visible on dashboard
- Helps with inventory management

### Responsive Design
- Works on desktop, tablet, mobile
- Adaptive layout
- Touch-friendly interface

## Performance Optimization

- Lazy loading of images
- Efficient Firestore queries
- CSS Grid for layout
- Minified assets
- Offline persistence enabled

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## Deployment

### Firebase Hosting

1. Install Firebase CLI: `npm install -g firebase-tools`
2. Initialize: `firebase init`
3. Deploy: `firebase deploy`

See `DEPLOYMENT.md` for detailed instructions.

## Security Features

- ✅ Firebase Authentication
- ✅ User data isolation
- ✅ Secure Firestore rules
- ✅ Input validation
- ✅ Password hashing
- ✅ HTTPS only
- ✅ Offline security

## Troubleshooting

### Firebase Connection Issues
- Verify API keys in `firebase-config.js`
- Check internet connection
- Clear browser cache
- Check Firestore rules

### Image Upload Not Working
- Check Firebase Storage rules
- Verify file size < 5MB
- Check file format (JPG, PNG, GIF)
- Verify storage bucket configuration

### Invoice Not Generating
- Ensure products are in cart
- Check customer name is entered
- Verify GST percentage
- Check Firestore write permissions

## Limitations & Future Enhancements

### Current Limitations
- Single user per account
- No multi-user support
- Limited payment gateway integration
- No SMS notifications

### Future Enhancements
- Multi-user accounts with roles
- Payment gateway integration (Razorpay, PayPal)
- SMS/Email notifications
- Advanced reporting
- Expense tracking
- Stock forecasting
- Mobile app
- Real-time synchronization

## Code Quality

- Clean, modular code
- Proper error handling
- Input validation
- Comments for clarity
- Follows best practices
- ES6+ standards

## Learning Resources

- [Firebase Documentation](https://firebase.google.com/docs)
- [Bootstrap Documentation](https://getbootstrap.com/docs)
- [MDN Web Docs](https://developer.mozilla.org)
- [JavaScript ES6+ Guide](https://www.javascripttutorial.net)

## License

This project is created for educational purposes as a Final Year BCA Project.

## Author

Created as a comprehensive Final Year BCA Project demonstrating modern web development practices.

## Support & Contact

For issues or questions:
- Check the documentation
- Review troubleshooting section
- Verify Firebase configuration
- Clear browser cache and reload

## Project Statistics

- **Lines of Code**: 5000+
- **Files**: 20+
- **Features**: 50+
- **Database Collections**: 4
- **JavaScript Modules**: 8+
- **Responsive Breakpoints**: 3+

## Version History

**v1.0.0** - Initial Release
- All core features implemented
- Responsive design
- Dashboard analytics
- Invoice generation with PDF and QR codes
- Product and customer management
- Inventory tracking
- Sales reports

---

**Smart Retail Hub** - Making retail management smarter and easier! 🎉
