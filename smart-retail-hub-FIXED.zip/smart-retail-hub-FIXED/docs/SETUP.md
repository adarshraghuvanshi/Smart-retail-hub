# Smart Retail Hub - Setup & Installation Guide

This guide provides step-by-step instructions to set up and deploy the Smart Retail Hub application.

## Prerequisites

Before starting, ensure you have:
- A modern web browser (Chrome, Firefox, Safari, or Edge)
- A Google account (for Firebase)
- Text editor or IDE (VS Code recommended)
- Basic knowledge of Firebase and web development

## Step 1: Firebase Project Setup

### 1.1 Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create Project"
3. Enter project name: "SmartRetailHub"
4. Accept terms and click "Create Project"
5. Wait for project creation to complete

### 1.2 Enable Authentication

1. In Firebase Console, click "Authentication" in sidebar
2. Click "Get Started"
3. Click "Email/Password" provider
4. Enable "Email/Password"
5. Click "Save"

### 1.3 Create Firestore Database

1. Click "Firestore Database" in sidebar
2. Click "Create Database"
3. Choose location (preferably closest to you)
4. Select "Start in test mode" (change later for production)
5. Click "Enable"

### 1.4 Enable Cloud Storage

1. Click "Storage" in sidebar
2. Click "Get Started"
3. Choose location (same as Firestore)
4. Click "Done"

### 1.5 Get Firebase Configuration

1. Click Project Settings (gear icon) → "Project Settings"
2. Scroll to "Your apps"
3. Click "Web" icon (</> symbol)
4. Register app and copy config
5. You'll get something like:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyD...",
  authDomain: "project.firebaseapp.com",
  projectId: "project-id",
  storageBucket: "project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc..."
};
```

## Step 2: Configure Application

### 2.1 Update Firebase Config

1. Open `firebase-config.js`
2. Replace `YOUR_API_KEY`, `YOUR_PROJECT`, etc. with actual values from Step 1.5
3. Save the file

Example:
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyDv3...",
  authDomain: "smartretailhub.firebaseapp.com",
  projectId: "smartretailhub-12345",
  storageBucket: "smartretailhub-12345.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abc1234def5678"
};
```

### 2.2 Configure Firestore Security Rules

1. In Firebase Console, go to "Firestore Database"
2. Click "Rules" tab
3. Replace rules with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Ensure user can only access their own data
    match /users/{userId} {
      allow read, write: if request.auth.uid == userId;
    }
    
    match /products/{document=**} {
      allow read, write: if request.auth.uid == resource.data.uid;
      allow create: if request.auth.uid == request.resource.data.uid;
    }
    
    match /customers/{document=**} {
      allow read, write: if request.auth.uid == resource.data.uid;
      allow create: if request.auth.uid == request.resource.data.uid;
    }
    
    match /bills/{document=**} {
      allow read, write: if request.auth.uid == resource.data.uid;
      allow create: if request.auth.uid == request.resource.data.uid;
    }
    
    match /inventory/{document=**} {
      allow read, write: if request.auth.uid == resource.data.uid;
      allow create: if request.auth.uid == request.resource.data.uid;
    }
  }
}
```

4. Click "Publish"

### 2.3 Configure Storage Rules

1. Go to "Storage"
2. Click "Rules" tab
3. Replace with:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /products/{userId}/{allPaths=**} {
      allow read, write: if request.auth.uid == userId;
    }
  }
}
```

4. Click "Publish"

## Step 3: Local Development

### 3.1 Download Files

1. Download all project files
2. Create a folder: `smart-retail-hub`
3. Extract files into the folder
4. Verify folder structure

### 3.2 Run Locally

#### Option A: Using Python Server

```bash
# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
```

#### Option B: Using Node.js

```bash
# Install http-server globally
npm install -g http-server

# Run server
http-server
```

#### Option C: Using VS Code Live Server

1. Install "Live Server" extension in VS Code
2. Right-click `login.html`
3. Select "Open with Live Server"

### 3.3 Access Application

1. Open browser
2. Go to `http://localhost:8000` (or port shown)
3. You should see the login page

## Step 4: Testing the Application

### 4.1 Create Test Account

1. Click "Sign Up"
2. Enter test details:
   - Shop Name: "Test Shop"
   - Email: "test@example.com"
   - Password: "Test123456"
3. Confirm password
4. Click "Create Account"

### 4.2 Login

1. Enter email: "test@example.com"
2. Enter password: "Test123456"
3. Click "Login"
4. You should see the dashboard

### 4.3 Test Features

**Dashboard:**
- Check if stats cards load
- Try to interact with charts
- Check responsive design

**Products:**
- Click "Add New Product"
- Fill in test product
- Try to upload image
- Save and verify

**Billing:**
- Create invoice with test product
- Generate PDF
- Print invoice
- Check QR code

**Customers:**
- Add test customer
- View customer details

## Step 5: Firebase Hosting Deployment

### 5.1 Install Firebase CLI

```bash
npm install -g firebase-tools
```

### 5.2 Login to Firebase

```bash
firebase login
```

### 5.3 Initialize Firebase

```bash
firebase init
```

Choose options:
- Hosting: Yes
- Project: Select your project
- Public directory: current (or .)
- Single-page app: No
- Overwrite: No

### 5.4 Deploy

```bash
firebase deploy --only hosting
```

You'll get a hosting URL like: `https://smartretailhub-xxx.web.app`

## Step 6: Production Setup

### 6.1 Update Security Rules

Change Firestore rules from test mode to:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null && 
        request.auth.uid == get(/databases/$(database)/documents/users/$(request.auth.uid)).uid;
    }
  }
}
```

### 6.2 Setup Email Authentication

1. Go to Authentication → Templates
2. Customize password reset email
3. Setup verified sender email

### 6.3 Enable Backup

1. Go to Firestore → Backups
2. Schedule daily backups
3. Set retention period

## Step 7: Monitoring & Analytics

### 7.1 Enable Google Analytics

1. Project Settings → Integration
2. Enable Google Analytics
3. Configure events tracking

### 7.2 Monitor Performance

1. Check Firebase Console for:
   - Authentication metrics
   - Firestore usage
   - Storage usage
   - Performance stats

## Troubleshooting

### Issue: Firebase Config Not Working

**Solution:**
- Verify all keys are correct
- Check authentication is enabled
- Check Firestore database exists
- Clear browser cache

### Issue: Can't Upload Images

**Solution:**
- Check Storage is enabled
- Verify storage rules are correct
- Check file size < 5MB
- Use supported formats (JPG, PNG, GIF)

### Issue: Invoice Not Saving

**Solution:**
- Check Firestore is accessible
- Verify user is authenticated
- Check collection permissions
- Check browser console for errors

### Issue: Dashboard Shows No Data

**Solution:**
- Verify data exists in Firestore
- Check user UID matches
- Check Firestore rules allow reads
- Clear localStorage and reload

### Issue: Dark Mode Not Working

**Solution:**
- Check localStorage is enabled
- Clear cache and try again
- Try different browser

## Browser DevTools Debugging

### Check Console Errors

1. Open DevTools (F12)
2. Go to Console tab
3. Look for red error messages
4. Read error details for solutions

### Check Network Requests

1. Go to Network tab
2. Reload page
3. Look for failed requests
4. Check Firebase endpoints

### Check Storage

1. Go to Application tab
2. Check localStorage
3. Check sessionStorage
4. Check indexedDB for offline data

## Performance Optimization Tips

1. **Enable Compression** - Use gzip compression
2. **Minify CSS/JS** - Use minification tools
3. **Cache Images** - Set browser cache headers
4. **CDN Usage** - Firebase Hosting uses CDN automatically
5. **Database Indexing** - Create Firestore indexes for better queries

## Backup & Recovery

### Backup Firestore Data

1. Go to Firestore Database
2. Click "Create Collection"
3. Export data using Firebase CLI:

```bash
firebase firestore:export ./backup
```

### Restore Firestore Data

```bash
firebase firestore:import ./backup
```

## Additional Resources

- **Firebase Docs**: https://firebase.google.com/docs
- **Bootstrap Docs**: https://getbootstrap.com/docs
- **Chart.js Docs**: https://www.chartjs.org/docs
- **Firebase CLI**: https://firebase.google.com/docs/cli

## Support Channels

- Firebase Support: https://firebase.google.com/support
- Stack Overflow: Use `firebase` tag
- GitHub Issues: Create issue in repository

## Next Steps

1. ✅ Setup complete
2. Test all features thoroughly
3. Customize branding if needed
4. Set up user accounts
5. Import initial product data
6. Train users
7. Monitor usage and performance
8. Regular backups

---

**Congratulations! Your Smart Retail Hub is ready to use!** 🎉

For more help, refer to README.md or check the troubleshooting section.
