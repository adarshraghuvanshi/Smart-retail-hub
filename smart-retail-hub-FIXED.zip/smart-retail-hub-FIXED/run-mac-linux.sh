#!/bin/bash
echo "Starting Smart Retail Hub..."
echo ""
python3 -m http.server 8000
