import { auth, db } from '../firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";

let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupEventListeners();
    initializeDarkMode();
});

function setupEventListeners() {
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
    document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebar);
    document.getElementById('themeToggle')?.addEventListener('click', toggleDarkMode);
}

function checkAuth() {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            loadUserData();
            loadInventory();
        } else {
            window.location.href = '../login.html';
        }
    });
}

function loadUserData() {
    const userEmail = currentUser.email;
    const firstName = userEmail.split('@')[0];
    document.getElementById('userName').textContent = firstName.charAt(0).toUpperCase() + firstName.slice(1);
}

async function loadInventory() {
    try {
        const uid = currentUser.uid;
        const q = query(collection(db, 'products'), where('uid', '==', uid));
        const snapshot = await getDocs(q);
        const products = [];
        let totalItems = 0, lowStock = 0, inStock = 0;

        snapshot.forEach(doc => {
            const product = { id: doc.id, ...doc.data() };
            products.push(product);
            totalItems++;
            if (product.quantity < 10) lowStock++;
            else inStock++;
        });

        document.getElementById('totalItems').textContent = totalItems;
        document.getElementById('lowStockItems').textContent = lowStock;
        document.getElementById('inStockItems').textContent = inStock;
        displayInventory(products);
    } catch (error) {
        console.error('Error loading inventory:', error);
    }
}

function displayInventory(products) {
    const tbody = document.getElementById('inventoryTable');
    if (products.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No products</td></tr>';
        return;
    }
    let html = '';
    products.forEach(product => {
        const status = product.quantity < 10 ? '<span class="badge bg-danger">Low Stock</span>' : '<span class="badge bg-success">In Stock</span>';
        html += `<tr>
            <td><strong>${product.productName}</strong></td>
            <td>${product.category}</td>
            <td>${product.quantity}</td>
            <td>10</td>
            <td>${status}</td>
            <td><a href="products.html" class="btn btn-sm btn-info">Update</a></td>
        </tr>`;
    });
    tbody.innerHTML = html;
}

async function logout(e) {
    e.preventDefault();
    try {
        await signOut(auth);
        window.location.href = '../login.html';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.style.display = sidebar.style.display === 'none' ? 'block' : 'none';
}

function toggleDarkMode() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

function initializeDarkMode() {
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }
}
