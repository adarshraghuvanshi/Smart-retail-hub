// Products Page JavaScript - Smart Retail Hub
import { auth, db, storage } from '../firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { 
    collection, 
    query, 
    where, 
    getDocs, 
    addDoc, 
    updateDoc, 
    deleteDoc, 
    doc,
    Timestamp
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";
import { 
    ref, 
    uploadBytes, 
    getDownloadURL,
    deleteObject 
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-storage.js";

let currentUser = null;
let editingProductId = null;

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupEventListeners();
    initializeDarkMode();
});

function setupEventListeners() {
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
    document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebar);
    document.getElementById('themeToggle')?.addEventListener('click', toggleDarkMode);
    document.getElementById('saveProductBtn').addEventListener('click', saveProduct);
    document.getElementById('searchProducts').addEventListener('keyup', filterProducts);
    document.getElementById('productImage').addEventListener('change', previewImage);
    document.getElementById('addProductModal').addEventListener('hidden.bs.modal', resetForm);
}

function checkAuth() {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            loadUserData();
            loadProducts();
        } else {
            window.location.href = '../login.html';
        }
    });
}

function loadUserData() {
    const userEmail = currentUser.email;
    const firstName = userEmail.split('@')[0];
    document.getElementById('userName').textContent = firstName.charAt(0).toUpperCase() + firstName.slice(1);
}

async function loadProducts() {
    try {
        const uid = currentUser.uid;
        const q = query(collection(db, 'products'), where('uid', '==', uid));
        const snapshot = await getDocs(q);
        
        const products = [];
        snapshot.forEach(doc => {
            products.push({
                id: doc.id,
                ...doc.data()
            });
        });
        
        displayProducts(products);
        document.getElementById('productCount').textContent = products.length;
    } catch (error) {
        console.error('Error loading products:', error);
        showAlert('Error loading products', 'danger');
    }
}

function displayProducts(products) {
    const tbody = document.getElementById('productsTable');
    
    if (products.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No products found</td></tr>';
        return;
    }
    
    let html = '';
    products.forEach(product => {
        html += `
            <tr>
                <td><strong>${product.productName}</strong></td>
                <td><span class="badge bg-light text-dark">${product.category}</span></td>
                <td>₹${(product.price || 0).toFixed(2)}</td>
                <td>
                    ${product.quantity < 10 ? 
                        `<span class="badge bg-danger">${product.quantity}</span>` : 
                        `<span>${product.quantity}</span>`
                    }
                </td>
                <td>
                    ${product.imageURL ? 
                        `<img src="${product.imageURL}" style="width: 40px; height: 40px; border-radius: 5px; object-fit: cover;">` : 
                        `<i class="fas fa-image text-muted"></i>`
                    }
                </td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick="editProduct('${product.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteProduct('${product.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

window.editProduct = async function(id) {
    try {
        const docSnapshot = await getDocs(query(
            collection(db, 'products'),
            where('uid', '==', currentUser.uid)
        ));
        
        let product = null;
        docSnapshot.forEach(doc => {
            if (doc.id === id) {
                product = { id: doc.id, ...doc.data() };
            }
        });
        
        if (!product) return;
        
        editingProductId = id;
        document.getElementById('productId').value = id;
        document.getElementById('productName').value = product.productName;
        document.getElementById('category').value = product.category;
        document.getElementById('price').value = product.price;
        document.getElementById('quantity').value = product.quantity;
        
        if (product.imageURL) {
            document.getElementById('imagePreview').style.display = 'block';
            document.getElementById('previewImg').src = product.imageURL;
        }
        
        document.getElementById('modalTitle').textContent = 'Edit Product';
        const modal = new bootstrap.Modal(document.getElementById('addProductModal'));
        modal.show();
    } catch (error) {
        console.error('Error editing product:', error);
    }
};

window.deleteProduct = async function(id) {
    if (!confirm('Are you sure you want to delete this product?')) return;
    
    try {
        await deleteDoc(doc(db, 'products', id));
        showAlert('Product deleted successfully', 'success');
        loadProducts();
    } catch (error) {
        console.error('Error deleting product:', error);
        showAlert('Error deleting product', 'danger');
    }
};

async function saveProduct() {
    const productName = document.getElementById('productName').value;
    const category = document.getElementById('category').value;
    const price = parseFloat(document.getElementById('price').value);
    const quantity = parseInt(document.getElementById('quantity').value);
    const imageFile = document.getElementById('productImage').files[0];
    
    if (!productName || !category || !price || quantity === '') {
        showAlert('Please fill all required fields', 'warning');
        return;
    }
    
    try {
        let imageURL = '';
        
        if (imageFile) {
            const storageRef = ref(storage, `products/${currentUser.uid}/${Date.now()}`);
            await uploadBytes(storageRef, imageFile);
            imageURL = await getDownloadURL(storageRef);
        }
        
        const productData = {
            productName,
            category,
            price,
            quantity,
            uid: currentUser.uid,
            createdAt: Timestamp.now()
        };
        
        if (imageURL) {
            productData.imageURL = imageURL;
        }
        
        if (editingProductId) {
            await updateDoc(doc(db, 'products', editingProductId), productData);
            showAlert('Product updated successfully', 'success');
        } else {
            await addDoc(collection(db, 'products'), productData);
            showAlert('Product added successfully', 'success');
        }
        
        const modal = bootstrap.Modal.getInstance(document.getElementById('addProductModal'));
        modal.hide();
        resetForm();
        loadProducts();
    } catch (error) {
        console.error('Error saving product:', error);
        showAlert('Error saving product', 'danger');
    }
}

function previewImage(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            document.getElementById('previewImg').src = event.target.result;
            document.getElementById('imagePreview').style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
}

function filterProducts() {
    const searchTerm = document.getElementById('searchProducts').value.toLowerCase();
    const rows = document.querySelectorAll('#productsTable tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function resetForm() {
    document.getElementById('productForm').reset();
    document.getElementById('productId').value = '';
    document.getElementById('imagePreview').style.display = 'none';
    document.getElementById('modalTitle').textContent = 'Add New Product';
    editingProductId = null;
}

async function logout(e) {
    e.preventDefault();
    try {
        await signOut(auth);
        window.location.href = '../login.html';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.style.display = sidebar.style.display === 'none' ? 'block' : 'none';
}

function toggleDarkMode() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

function initializeDarkMode() {
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }
}

function showAlert(message, type = 'info') {
    const alertBox = document.getElementById('alertBox');
    const alertHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert" style="margin-top: 20px;">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    alertBox.innerHTML = alertHTML;
    setTimeout(() => {
        alertBox.innerHTML = '';
    }, 3000);
}
