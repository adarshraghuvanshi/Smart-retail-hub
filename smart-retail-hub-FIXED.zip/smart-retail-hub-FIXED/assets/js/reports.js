import { auth, db } from '../firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";

let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupEventListeners();
    initializeDarkMode();
});

function setupEventListeners() {
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
    document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebar);
    document.getElementById('themeToggle')?.addEventListener('click', toggleDarkMode);
}

function checkAuth() {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            loadUserData();
            loadReports();
        } else {
            window.location.href = '../login.html';
        }
    });
}

function loadUserData() {
    const userEmail = currentUser.email;
    const firstName = userEmail.split('@')[0];
    document.getElementById('userName').textContent = firstName.charAt(0).toUpperCase() + firstName.slice(1);
}

async function loadReports() {
    try {
        const uid = currentUser.uid;
        const q = query(collection(db, 'bills'), where('uid', '==', uid));
        const snapshot = await getDocs(q);
        
        const salesData = {};
        snapshot.forEach(doc => {
            const bill = doc.data();
            const date = bill.createdAt?.toDate?.() || new Date();
            const month = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            if (!salesData[month]) salesData[month] = { total: 0, count: 0 };
            salesData[month].total += bill.totalAmount;
            salesData[month].count++;
        });

        displayCharts(salesData);
        displaySalesSummary(salesData);
    } catch (error) {
        console.error('Error loading reports:', error);
    }
}

function displayCharts(salesData) {
    const ctx = document.getElementById('monthlySalesChart')?.getContext('2d');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(salesData),
            datasets: [{
                label: 'Monthly Sales (₹)',
                data: Object.values(salesData).map(d => d.total),
                backgroundColor: 'rgba(59, 130, 246, 0.6)',
                borderColor: 'rgb(59, 130, 246)',
                borderWidth: 1
            }]
        },
        options: { responsive: true, scales: { y: { beginAtZero: true } } }
    });
}

function displaySalesSummary(salesData) {
    const tbody = document.getElementById('salesSummary');
    let html = '';
    Object.entries(salesData).forEach(([month, data]) => {
        const avg = (data.total / data.count).toFixed(2);
        html += `<tr><td>${month}</td><td>₹${data.total.toFixed(2)}</td><td>${data.count}</td><td>₹${avg}</td></tr>`;
    });
    tbody.innerHTML = html;
}

async function logout(e) {
    e.preventDefault();
    try {
        await signOut(auth);
        window.location.href = '../login.html';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.style.display = sidebar.style.display === 'none' ? 'block' : 'none';
}

function toggleDarkMode() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

function initializeDarkMode() {
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }
}
