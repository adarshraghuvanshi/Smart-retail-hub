import { auth, db } from '../firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { collection, query, where, getDocs, addDoc, updateDoc, deleteDoc, doc, Timestamp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";

let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupEventListeners();
    initializeDarkMode();
});

function setupEventListeners() {
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
    document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebar);
    document.getElementById('themeToggle')?.addEventListener('click', toggleDarkMode);
    document.getElementById('saveCustomerBtn').addEventListener('click', saveCustomer);
}

function checkAuth() {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            loadUserData();
            loadCustomers();
        } else {
            window.location.href = '../login.html';
        }
    });
}

function loadUserData() {
    const userEmail = currentUser.email;
    const firstName = userEmail.split('@')[0];
    document.getElementById('userName').textContent = firstName.charAt(0).toUpperCase() + firstName.slice(1);
}

async function loadCustomers() {
    try {
        const uid = currentUser.uid;
        const q = query(collection(db, 'customers'), where('uid', '==', uid));
        const snapshot = await getDocs(q);
        const customers = [];
        snapshot.forEach(doc => {
            customers.push({ id: doc.id, ...doc.data() });
        });
        displayCustomers(customers);
        document.getElementById('customerCount').textContent = customers.length;
    } catch (error) {
        console.error('Error loading customers:', error);
    }
}

function displayCustomers(customers) {
    const tbody = document.getElementById('customersTable');
    if (customers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No customers found</td></tr>';
        return;
    }
    let html = '';
    customers.forEach(customer => {
        html += `<tr>
            <td><strong>${customer.customerName}</strong></td>
            <td>${customer.phone}</td>
            <td>${customer.address}</td>
            <td>₹${(customer.totalPurchases || 0).toFixed(2)}</td>
            <td>
                <button class="btn btn-sm btn-warning" onclick="editCustomer('${customer.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn btn-sm btn-danger" onclick="deleteCustomer('${customer.id}')"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    });
    tbody.innerHTML = html;
}

window.editCustomer = async function(id) {
    try {
        const docSnapshot = await getDocs(query(collection(db, 'customers'), where('uid', '==', currentUser.uid)));
        let customer = null;
        docSnapshot.forEach(doc => {
            if (doc.id === id) customer = { id: doc.id, ...doc.data() };
        });
        if (!customer) return;
        document.getElementById('customerId').value = id;
        document.getElementById('customerName').value = customer.customerName;
        document.getElementById('customerPhone').value = customer.phone;
        document.getElementById('customerAddress').value = customer.address;
        const modal = new bootstrap.Modal(document.getElementById('addCustomerModal'));
        modal.show();
    } catch (error) {
        console.error('Error:', error);
    }
};

window.deleteCustomer = async function(id) {
    if (!confirm('Delete this customer?')) return;
    try {
        await deleteDoc(doc(db, 'customers', id));
        showAlert('Customer deleted', 'success');
        loadCustomers();
    } catch (error) {
        showAlert('Error deleting customer', 'danger');
    }
};

async function saveCustomer() {
    const name = document.getElementById('customerName').value;
    const phone = document.getElementById('customerPhone').value;
    const address = document.getElementById('customerAddress').value;
    const id = document.getElementById('customerId').value;

    if (!name || !phone || !address) {
        showAlert('Please fill all fields', 'warning');
        return;
    }

    try {
        const data = { customerName: name, phone, address, uid: currentUser.uid };
        if (id) {
            await updateDoc(doc(db, 'customers', id), data);
            showAlert('Customer updated', 'success');
        } else {
            await addDoc(collection(db, 'customers'), { ...data, createdAt: Timestamp.now() });
            showAlert('Customer added', 'success');
        }
        const modal = bootstrap.Modal.getInstance(document.getElementById('addCustomerModal'));
        modal.hide();
        document.getElementById('customerForm').reset();
        loadCustomers();
    } catch (error) {
        showAlert('Error saving customer', 'danger');
    }
}

async function logout(e) {
    e.preventDefault();
    try {
        await signOut(auth);
        window.location.href = '../login.html';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.style.display = sidebar.style.display === 'none' ? 'block' : 'none';
}

function toggleDarkMode() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

function initializeDarkMode() {
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }
}

function showAlert(message, type = 'info') {
    const alertBox = document.getElementById('alertBox');
    const alertHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert" style="margin-top: 20px;">${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    alertBox.innerHTML = alertHTML;
    setTimeout(() => { alertBox.innerHTML = ''; }, 3000);
}
