import { auth, db } from '../firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { doc, getDoc, updateDoc } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";

let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupEventListeners();
    initializeDarkMode();
});

function setupEventListeners() {
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
    document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebar);
    document.getElementById('themeToggle')?.addEventListener('click', toggleDarkMode);
    document.getElementById('settingsForm')?.addEventListener('submit', saveSettings);
    document.getElementById('passwordForm')?.addEventListener('submit', changePassword);
}

function checkAuth() {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            loadUserData();
            loadSettings();
        } else {
            window.location.href = '../login.html';
        }
    });
}

function loadUserData() {
    const userEmail = currentUser.email;
    const firstName = userEmail.split('@')[0];
    document.getElementById('userName').textContent = firstName.charAt(0).toUpperCase() + firstName.slice(1);
}

async function loadSettings() {
    try {
        const docSnap = await getDoc(doc(db, 'users', currentUser.uid));
        if (docSnap.exists()) {
            const data = docSnap.data();
            document.getElementById('shopName').value = data.shopName || '';
            document.getElementById('ownerName').value = data.name || '';
            document.getElementById('shopPhone').value = data.phone || '';
            document.getElementById('shopAddress').value = data.address || '';
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

async function saveSettings(e) {
    e.preventDefault();
    try {
        await updateDoc(doc(db, 'users', currentUser.uid), {
            shopName: document.getElementById('shopName').value,
            name: document.getElementById('ownerName').value,
            phone: document.getElementById('shopPhone').value,
            address: document.getElementById('shopAddress').value
        });
        showAlert('Settings saved successfully', 'success');
    } catch (error) {
        showAlert('Error saving settings', 'danger');
    }
}

async function changePassword(e) {
    e.preventDefault();
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmNewPassword').value;
    
    if (newPassword !== confirmPassword) {
        showAlert('Passwords do not match', 'warning');
        return;
    }
    
    try {
        await currentUser.updatePassword(newPassword);
        showAlert('Password changed successfully', 'success');
        document.getElementById('passwordForm').reset();
    } catch (error) {
        showAlert('Error changing password', 'danger');
    }
}

async function logout(e) {
    e.preventDefault();
    try {
        await signOut(auth);
        window.location.href = '../login.html';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.style.display = sidebar.style.display === 'none' ? 'block' : 'none';
}

function toggleDarkMode() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

function initializeDarkMode() {
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }
}

function showAlert(message, type = 'info') {
    const alertBox = document.getElementById('alertBox');
    const alertHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert" style="margin-top: 20px;">${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    alertBox.innerHTML = alertHTML;
    setTimeout(() => { alertBox.innerHTML = ''; }, 3000);
}
