// Billing Page JavaScript - Smart Retail Hub
import { auth, db } from '../firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { 
    collection, 
    query, 
    where, 
    getDocs, 
    addDoc,
    Timestamp
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";

let currentUser = null;
let billItems = [];
let products = [];

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupEventListeners();
    initializeDarkMode();
});

function setupEventListeners() {
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
    document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebar);
    document.getElementById('themeToggle')?.addEventListener('click', toggleDarkMode);
    document.getElementById('addProductBtn').addEventListener('click', addProductToCart);
    document.getElementById('generateInvoiceBtn').addEventListener('click', generateInvoice);
    document.getElementById('printInvoiceBtn')?.addEventListener('click', printInvoice);
    document.getElementById('downloadPdfBtn')?.addEventListener('click', downloadPdf);
    document.getElementById('newInvoiceBtn')?.addEventListener('click', resetBilling);
    document.getElementById('gstPercent').addEventListener('change', updateBillingAmount);
}

function checkAuth() {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            loadUserData();
            loadProducts();
        } else {
            window.location.href = '../login.html';
        }
    });
}

function loadUserData() {
    const userEmail = currentUser.email;
    const firstName = userEmail.split('@')[0];
    document.getElementById('userName').textContent = firstName.charAt(0).toUpperCase() + firstName.slice(1);
}

async function loadProducts() {
    try {
        const uid = currentUser.uid;
        const q = query(collection(db, 'products'), where('uid', '==', uid));
        const snapshot = await getDocs(q);
        
        products = [];
        const productSelect = document.getElementById('productSelect');
        productSelect.innerHTML = '<option value="">Select a product...</option>';
        
        snapshot.forEach(doc => {
            const product = {
                id: doc.id,
                ...doc.data()
            };
            products.push(product);
            
            const option = document.createElement('option');
            option.value = product.id;
            option.textContent = `${product.productName} - ₹${product.price}`;
            productSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

function addProductToCart() {
    const productId = document.getElementById('productSelect').value;
    const quantity = parseInt(document.getElementById('quantityInput').value);
    
    if (!productId) {
        showAlert('Please select a product', 'warning');
        return;
    }
    
    if (!quantity || quantity <= 0) {
        showAlert('Please enter valid quantity', 'warning');
        return;
    }
    
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    if (quantity > product.quantity) {
        showAlert(`Only ${product.quantity} units available`, 'warning');
        return;
    }
    
    // Check if product already in cart
    const existingItem = billItems.find(item => item.id === productId);
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        billItems.push({
            id: productId,
            name: product.productName,
            price: product.price,
            quantity: quantity
        });
    }
    
    updateBillDisplay();
    document.getElementById('productSelect').value = '';
    document.getElementById('quantityInput').value = '';
}

function updateBillDisplay() {
    const tbody = document.getElementById('billItems');
    
    if (billItems.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-muted text-center">No items added</td></tr>';
        return;
    }
    
    let html = '';
    billItems.forEach((item, index) => {
        const total = item.price * item.quantity;
        html += `
            <tr>
                <td>${item.name}</td>
                <td>₹${item.price}</td>
                <td>${item.quantity}</td>
                <td>₹${total.toFixed(2)}</td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="removeItem(${index})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    updateBillingAmount();
}

window.removeItem = function(index) {
    billItems.splice(index, 1);
    updateBillDisplay();
};

function updateBillingAmount() {
    const subtotal = billItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const gstPercent = parseFloat(document.getElementById('gstPercent').value) || 0;
    const gstAmount = (subtotal * gstPercent) / 100;
    const total = subtotal + gstAmount;
    
    document.getElementById('subtotal').textContent = '₹' + subtotal.toFixed(2);
    document.getElementById('gstAmount').textContent = '₹' + gstAmount.toFixed(2);
    document.getElementById('totalAmount').textContent = '₹' + total.toFixed(2);
}

async function generateInvoice() {
    const customerName = document.getElementById('customerName').value;
    
    if (!customerName) {
        showAlert('Please enter customer name', 'warning');
        return;
    }
    
    if (billItems.length === 0) {
        showAlert('Please add products to the bill', 'warning');
        return;
    }
    
    try {
        const subtotal = billItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const gstPercent = parseFloat(document.getElementById('gstPercent').value) || 0;
        const gstAmount = (subtotal * gstPercent) / 100;
        const totalAmount = subtotal + gstAmount;
        
        // Save to Firestore
        const billData = {
            uid: currentUser.uid,
            customerName: customerName,
            products: billItems.map(item => ({
                name: item.name,
                quantity: item.quantity,
                price: item.price,
                total: item.price * item.quantity
            })),
            subtotal: subtotal,
            gst: gstAmount,
            totalAmount: totalAmount,
            gstPercent: gstPercent,
            createdAt: Timestamp.now()
        };
        
        const docRef = await addDoc(collection(db, 'bills'), billData);
        
        // Display invoice
        displayInvoice(docRef.id, customerName, subtotal, gstAmount, totalAmount);
        
        showAlert('Invoice generated successfully', 'success');
    } catch (error) {
        console.error('Error generating invoice:', error);
        showAlert('Error generating invoice', 'danger');
    }
}

function displayInvoice(invoiceId, customerName, subtotal, gstAmount, totalAmount) {
    const container = document.getElementById('invoiceContainer');
    
    // Set invoice details
    document.getElementById('invoiceId').textContent = invoiceId.slice(0, 8).toUpperCase();
    document.getElementById('invoiceDate').textContent = new Date().toLocaleDateString();
    document.getElementById('billToName').textContent = customerName;
    
    // Set invoice items
    let itemsHtml = '';
    billItems.forEach(item => {
        const itemTotal = item.price * item.quantity;
        itemsHtml += `
            <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 10px;">${item.name}</td>
                <td style="padding: 10px; text-align: center;">${item.quantity}</td>
                <td style="padding: 10px; text-align: right;">₹${item.price.toFixed(2)}</td>
                <td style="padding: 10px; text-align: right;">₹${itemTotal.toFixed(2)}</td>
            </tr>
        `;
    });
    document.getElementById('invoiceItems').innerHTML = itemsHtml;
    
    // Set totals
    document.getElementById('invSubtotal').textContent = '₹' + subtotal.toFixed(2);
    document.getElementById('invGst').textContent = '₹' + gstAmount.toFixed(2);
    document.getElementById('invTotal').textContent = '₹' + totalAmount.toFixed(2);
    
    // Generate QR Code
    generateQRCode(invoiceId);
    
    container.style.display = 'block';
}

function generateQRCode(invoiceId) {
    const qrcodeContainer = document.getElementById('qrcodeContainer');
    qrcodeContainer.innerHTML = '';
    
    const qrData = `Invoice: ${invoiceId}\nAmount: ${document.getElementById('invTotal').textContent}`;
    
    new QRCode(qrcodeContainer, {
        text: qrData,
        width: 150,
        height: 150,
        colorDark: '#0f172a',
        colorLight: '#ffffff'
    });
}

function printInvoice() {
    const invoicePrint = document.getElementById('invoicePrint');
    const printWindow = window.open('', '', 'height=600,width=800');
    
    printWindow.document.write('<html><head><title>Invoice</title>');
    printWindow.document.write('<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">');
    printWindow.document.write('</head><body>');
    printWindow.document.write(invoicePrint.innerHTML);
    printWindow.document.write('</body></html>');
    
    printWindow.document.close();
    printWindow.print();
}

function downloadPdf() {
    const invoicePrint = document.getElementById('invoicePrint');
    const invoiceId = document.getElementById('invoiceId').textContent;
    
    const element = invoicePrint;
    const opt = {
        margin: 10,
        filename: `Invoice_${invoiceId}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { orientation: 'portrait', unit: 'mm', format: 'a4' }
    };
    
    html2pdf().set(opt).from(element).save();
}

function resetBilling() {
    billItems = [];
    document.getElementById('customerName').value = '';
    document.getElementById('productSelect').value = '';
    document.getElementById('quantityInput').value = '';
    document.getElementById('gstPercent').value = '18';
    updateBillDisplay();
    document.getElementById('invoiceContainer').style.display = 'none';
}

async function logout(e) {
    e.preventDefault();
    try {
        await signOut(auth);
        window.location.href = '../login.html';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.style.display = sidebar.style.display === 'none' ? 'block' : 'none';
}

function toggleDarkMode() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

function initializeDarkMode() {
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }
}

function showAlert(message, type = 'info') {
    const alertBox = document.getElementById('alertBox');
    const alertHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    alertBox.innerHTML = alertHTML;
    setTimeout(() => {
        alertBox.innerHTML = '';
    }, 3000);
}
