// Login Page JavaScript - Smart Retail Hub
import { auth, db } from '../firebase-config.js';
import { 
    signInWithEmailAndPassword, 
    createUserWithEmailAndPassword,
    sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { 
    setDoc, 
    doc 
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";

const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
const forgotPasswordForm = document.getElementById('forgotPasswordForm');
const alertBox = document.getElementById('alertBox');

// Show Alert Message
function showAlert(message, type = 'danger') {
    const alertHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    alertBox.innerHTML = alertHTML;
    setTimeout(() => {
        alertBox.innerHTML = '';
    }, 5000);
}

// Login Form Handler
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('rememberMe').checked;
    
    const loginBtn = document.querySelector('.btn-login');
    const loginBtnText = document.getElementById('loginBtnText');
    const loginBtnSpinner = document.getElementById('loginBtnSpinner');
    
    // Disable button
    loginBtn.disabled = true;
    loginBtnText.textContent = 'Logging in...';
    loginBtnSpinner.style.display = 'inline-block';
    
    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        
        // Store remember me preference
        if (rememberMe) {
            localStorage.setItem('rememberEmail', email);
        } else {
            localStorage.removeItem('rememberEmail');
        }
        
        showAlert('Login successful! Redirecting...', 'success');
        
        // Redirect to dashboard
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
        
    } catch (error) {
        let errorMessage = 'Login failed. Please try again.';
        
        if (error.code === 'auth/user-not-found') {
            errorMessage = 'Email not found. Please sign up first.';
        } else if (error.code === 'auth/wrong-password') {
            errorMessage = 'Incorrect password. Please try again.';
        } else if (error.code === 'auth/invalid-email') {
            errorMessage = 'Invalid email address.';
        } else if (error.code === 'auth/user-disabled') {
            errorMessage = 'This account has been disabled.';
        }
        
        showAlert(errorMessage);
        loginBtn.disabled = false;
        loginBtnText.textContent = 'Login';
        loginBtnSpinner.style.display = 'none';
    }
});

// Signup Form Handler
signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const shopName = document.getElementById('shopName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (password !== confirmPassword) {
        showAlert('Passwords do not match!');
        return;
    }
    
    if (password.length < 6) {
        showAlert('Password must be at least 6 characters long!');
        return;
    }
    
    const signupBtn = document.querySelector('#signupForm button[type="submit"]');
    const originalBtnText = signupBtn.textContent;
    
    signupBtn.disabled = true;
    signupBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Creating Account...';
    
    try {
        // Create user account
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Store user data in Firestore
        await setDoc(doc(db, 'users', user.uid), {
            name: shopName,
            email: email,
            role: 'owner',
            createdAt: new Date(),
            shopName: shopName,
            phone: '',
            address: '',
            city: '',
            state: ''
        });
        
        showAlert('Account created successfully! Please login.', 'success');
        
        // Reset form
        signupForm.reset();
        
        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('signupModal'));
        modal.hide();
        
        // Pre-fill email
        document.getElementById('email').value = email;
        
    } catch (error) {
        let errorMessage = 'Signup failed. Please try again.';
        
        if (error.code === 'auth/email-already-in-use') {
            errorMessage = 'This email is already registered. Please login.';
        } else if (error.code === 'auth/weak-password') {
            errorMessage = 'Password is too weak. Use at least 6 characters.';
        } else if (error.code === 'auth/invalid-email') {
            errorMessage = 'Invalid email address.';
        }
        
        showAlert(errorMessage);
        signupBtn.disabled = false;
        signupBtn.textContent = originalBtnText;
    }
});

// Forgot Password Handler
forgotPasswordForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const resetEmail = document.getElementById('resetEmail').value;
    const resetBtn = document.querySelector('#forgotPasswordForm button[type="submit"]');
    const originalBtnText = resetBtn.textContent;
    
    resetBtn.disabled = true;
    resetBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sending...';
    
    try {
        await sendPasswordResetEmail(auth, resetEmail);
        showAlert('Password reset email sent! Check your inbox.', 'success');
        
        forgotPasswordForm.reset();
        
        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('forgotPasswordModal'));
        modal.hide();
        
    } catch (error) {
        let errorMessage = 'Error sending reset email. Please try again.';
        
        if (error.code === 'auth/user-not-found') {
            errorMessage = 'Email not found in our system.';
        } else if (error.code === 'auth/invalid-email') {
            errorMessage = 'Invalid email address.';
        }
        
        showAlert(errorMessage);
        resetBtn.disabled = false;
        resetBtn.textContent = originalBtnText;
    }
});

// Load saved email on page load
window.addEventListener('DOMContentLoaded', () => {
    const savedEmail = localStorage.getItem('rememberEmail');
    if (savedEmail) {
        document.getElementById('email').value = savedEmail;
        document.getElementById('rememberMe').checked = true;
    }
});

// Check if user is already logged in
auth.onAuthStateChanged((user) => {
    if (user) {
        window.location.href = 'dashboard.html';
    }
});
