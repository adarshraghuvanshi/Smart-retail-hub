// Dashboard JavaScript - Smart Retail Hub
import { auth, db } from '../firebase-config.js';
import { 
    onAuthStateChanged, 
    signOut 
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { 
    collection, 
    query, 
    where, 
    getDocs, 
    orderBy, 
    limit,
    onSnapshot,
    sum,
    getAggregateFromServer,
    Timestamp
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";

let currentUser = null;
let salesChart = null;
let revenueChart = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    checkAuth();
    initializeDarkMode();
});

// Setup Event Listeners
function setupEventListeners() {
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
    document.getElementById('logoutBtnDropdown')?.addEventListener('click', logout);
    document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebar);
    document.getElementById('themeToggle')?.addEventListener('click', toggleDarkMode);
    document.getElementById('chartTimeframe')?.addEventListener('change', loadSalesChart);
}

// Check Authentication
function checkAuth() {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            loadUserData();
            loadDashboardData();
        } else {
            window.location.href = 'login.html';
        }
    });
}

// Load User Data
async function loadUserData() {
    try {
        const userEmail = currentUser.email;
        const firstName = userEmail.split('@')[0];
        document.getElementById('userName').textContent = firstName.charAt(0).toUpperCase() + firstName.slice(1);
    } catch (error) {
        console.error('Error loading user data:', error);
    }
}

// Load Dashboard Data
async function loadDashboardData() {
    try {
        const uid = currentUser.uid;
        
        // Load all dashboard metrics
        await Promise.all([
            loadTotalProducts(uid),
            loadTotalCustomers(uid),
            loadTotalSales(uid),
            loadLowStockItems(uid),
            loadRecentInvoices(uid),
            loadSalesChart(),
            loadRevenueChart(uid)
        ]);
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

// Load Total Products
async function loadTotalProducts(uid) {
    try {
        const q = query(collection(db, 'products'), where('uid', '==', uid));
        const snapshot = await getDocs(q);
        const count = snapshot.size;
        document.getElementById('totalProducts').textContent = count;
    } catch (error) {
        console.error('Error loading total products:', error);
    }
}

// Load Total Customers
async function loadTotalCustomers(uid) {
    try {
        const q = query(collection(db, 'customers'), where('uid', '==', uid));
        const snapshot = await getDocs(q);
        const count = snapshot.size;
        document.getElementById('totalCustomers').textContent = count;
    } catch (error) {
        console.error('Error loading total customers:', error);
    }
}

// Load Total Sales
async function loadTotalSales(uid) {
    try {
        const q = query(collection(db, 'bills'), where('uid', '==', uid));
        const snapshot = await getDocs(q);
        
        let total = 0;
        snapshot.forEach(doc => {
            total += doc.data().totalAmount || 0;
        });
        
        document.getElementById('totalSales').textContent = '₹' + total.toLocaleString();
    } catch (error) {
        console.error('Error loading total sales:', error);
    }
}

// Load Low Stock Items
async function loadLowStockItems(uid) {
    try {
        const q = query(
            collection(db, 'products'), 
            where('uid', '==', uid),
            where('quantity', '<', 10)
        );
        const snapshot = await getDocs(q);
        const count = snapshot.size;
        
        document.getElementById('lowStockCount').textContent = count;
        
        if (count > 0) {
            displayLowStockAlert(snapshot);
        }
    } catch (error) {
        console.error('Error loading low stock items:', error);
    }
}

// Display Low Stock Alert
function displayLowStockAlert(snapshot) {
    const alertSection = document.getElementById('lowStockAlert');
    const lowStockItems = document.getElementById('lowStockItems');
    let html = '<ul class="list-unstyled">';
    
    snapshot.forEach(doc => {
        const product = doc.data();
        html += `
            <li class="mb-2">
                <strong>${product.productName}</strong> - 
                <span class="badge bg-warning">${product.quantity} units</span>
            </li>
        `;
    });
    
    html += '</ul>';
    lowStockItems.innerHTML = html;
    alertSection.style.display = 'block';
}

// Load Recent Invoices
async function loadRecentInvoices(uid) {
    try {
        const q = query(
            collection(db, 'bills'),
            where('uid', '==', uid),
            orderBy('createdAt', 'desc'),
            limit(5)
        );
        
        const snapshot = await getDocs(q);
        const tbody = document.getElementById('recentInvoices');
        
        if (snapshot.empty) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No invoices yet</td></tr>';
            return;
        }
        
        let html = '';
        snapshot.forEach(doc => {
            const bill = doc.data();
            const date = bill.createdAt?.toDate?.() || new Date();
            const formattedDate = date.toLocaleDateString();
            
            html += `
                <tr>
                    <td><strong>${doc.id.slice(0, 8)}</strong></td>
                    <td>${bill.customerName}</td>
                    <td>₹${bill.totalAmount.toLocaleString()}</td>
                    <td>${formattedDate}</td>
                    <td><span class="badge badge-success">Completed</span></td>
                    <td>
                        <a href="pages/billing.html" class="btn btn-sm btn-primary">View</a>
                    </td>
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
    } catch (error) {
        console.error('Error loading recent invoices:', error);
        document.getElementById('recentInvoices').innerHTML = 
            '<tr><td colspan="6" class="text-center text-danger">Error loading invoices</td></tr>';
    }
}

// Load Sales Chart
async function loadSalesChart() {
    try {
        const uid = currentUser.uid;
        const timeframe = document.getElementById('chartTimeframe')?.value || 7;
        const days = parseInt(timeframe);
        
        // Generate data for the last N days
        const data = await generateSalesData(uid, days);
        
        const ctx = document.getElementById('salesChart')?.getContext('2d');
        if (!ctx) return;
        
        if (salesChart) {
            salesChart.destroy();
        }
        
        salesChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Sales (₹)',
                    data: data.sales,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 5,
                    pointBackgroundColor: '#3b82f6',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: true,
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            font: { size: 12, weight: 600 }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error loading sales chart:', error);
    }
}

// Generate Sales Data
async function generateSalesData(uid, days) {
    const labels = [];
    const sales = [];
    const today = new Date();
    
    // Generate past N days data
    for (let i = days - 1; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    }
    
    // Fetch bills for each day
    for (let i = days - 1; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        const startOfDay = new Date(date.setHours(0, 0, 0, 0));
        const endOfDay = new Date(date.setHours(23, 59, 59, 999));
        
        const q = query(
            collection(db, 'bills'),
            where('uid', '==', uid),
            where('createdAt', '>=', Timestamp.fromDate(startOfDay)),
            where('createdAt', '<=', Timestamp.fromDate(endOfDay))
        );
        
        const snapshot = await getDocs(q);
        let dailyTotal = 0;
        
        snapshot.forEach(doc => {
            dailyTotal += doc.data().totalAmount || 0;
        });
        
        sales.push(dailyTotal);
    }
    
    return { labels, sales };
}

// Load Revenue Chart
async function loadRevenueChart(uid) {
    try {
        const q = query(collection(db, 'bills'), where('uid', '==', uid));
        const snapshot = await getDocs(q);
        
        const categories = {};
        
        snapshot.forEach(doc => {
            const bill = doc.data();
            const products = bill.products || [];
            
            products.forEach(product => {
                const category = product.category || 'Uncategorized';
                if (!categories[category]) {
                    categories[category] = 0;
                }
                categories[category] += (product.price * product.quantity) || 0;
            });
        });
        
        const ctx = document.getElementById('revenueChart')?.getContext('2d');
        if (!ctx) return;
        
        if (revenueChart) {
            revenueChart.destroy();
        }
        
        const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
        
        revenueChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(categories),
                datasets: [{
                    data: Object.values(categories),
                    backgroundColor: colors.slice(0, Object.keys(categories).length),
                    borderColor: '#fff',
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            font: { size: 12, weight: 600 }
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error loading revenue chart:', error);
    }
}

// Logout Function
async function logout(e) {
    e.preventDefault();
    try {
        await signOut(auth);
        window.location.href = 'login.html';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.style.display = sidebar.style.display === 'none' ? 'block' : 'none';
}

// Dark Mode
function initializeDarkMode() {
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
    }
}

function toggleDarkMode() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
    
    const themeBtn = document.getElementById('themeToggle');
    if (isDarkMode) {
        themeBtn.innerHTML = '<i class="fas fa-sun"></i>';
    } else {
        themeBtn.innerHTML = '<i class="fas fa-moon"></i>';
    }
}

// Responsive Design
window.addEventListener('resize', () => {
    if (window.innerWidth < 768) {
        document.querySelector('.sidebar').style.position = 'absolute';
    }
});
